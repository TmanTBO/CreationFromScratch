package Control;

import java.awt.Color;

import javax.swing.*;
import javax.swing.border.LineBorder;

public class Panels extends JPanel{
	JButton one,two, three, four, five;
	JButton six, seven, eight, nine;
	JPanel Numbering, Display;
	public Panels(){
		
		Numbering = new JPanel();
		Display = new JPanel();
		
	}

}
